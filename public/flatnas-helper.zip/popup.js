document.addEventListener("DOMContentLoaded", () => {
  checkHandshake();

  document.getElementById("retryBtn").addEventListener("click", () => {
    document.getElementById("error-msg").style.display = "none";
    document.getElementById("checking").style.display = "block";
    checkHandshake();
  });

  // 绑定设置展开
  const toggleBtn = document.getElementById("toggleSettingsBtn");
  if (toggleBtn) {
    toggleBtn.addEventListener("click", (e) => {
      e.preventDefault();
      const panel = document.getElementById("settings-panel");
      if (panel.style.display === "none") {
        panel.style.display = "block";
        toggleBtn.textContent = "▲ 收起设置";
      } else {
        panel.style.display = "none";
        toggleBtn.textContent = "▼ 展开设置";
      }
    });
  }

  // 绑定强制进入按钮
  bindForceBtn();
});

function bindForceBtn() {
  const forceBtn = document.getElementById("forceBtn");
  if (forceBtn) {
    // 避免重复绑定
    const newForceBtn = forceBtn.cloneNode(true);
    forceBtn.parentNode.replaceChild(newForceBtn, forceBtn);

    newForceBtn.addEventListener("click", (e) => {
      e.preventDefault();
      document.getElementById("error-msg").style.display = "none";
      document.getElementById("checking").style.display = "none";
      document.getElementById("app-content").style.display = "block";
      document.getElementById("settings-panel").style.display = "block"; // 强制进入时展开设置
      initPopup();
    });
  }
}

async function checkHandshake() {
  const checkingEl = document.getElementById("checking");
  const appContentEl = document.getElementById("app-content");
  const errorMsgEl = document.getElementById("error-msg");
  const settingsPanel = document.getElementById("settings-panel");
  const toggleBtn = document.getElementById("toggleSettingsBtn");

  try {
    // Check Config First
    const storage = await chrome.storage.sync.get(["nasDomains"]);
    const configStr = storage.nasDomains || "";
    const hasConfig = configStr.trim().length > 0;

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab) {
      throw new Error("No active tab");
    }

    console.log("Checking tab:", tab.url);

    let isHandshakeValid = false;

    // Optimization: Skip handshake on browser pages or if url is missing
    const isSystemPage =
      !tab.url ||
      tab.url.startsWith("chrome://") ||
      tab.url.startsWith("edge://") ||
      tab.url.startsWith("about:") ||
      tab.url.startsWith("file://"); // file:// might be allowed but requires specific permission

    if (!isSystemPage) {
      try {
        // 握手检查：检查当前页面是否有特定类名的元素
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            const el = document.querySelector(".flatnas-handshake-signal");
            return !!el;
          },
        });
        isHandshakeValid = results && results[0] && results[0].result;
      } catch (e) {
        console.warn("Script execution failed (likely restricted page):", e);
        // Treat as not handshake valid
        isHandshakeValid = false;
      }
    }

    checkingEl.style.display = "none";

    if (isHandshakeValid) {
      // 1. On FlatNas Page -> Show Full UI
      appContentEl.style.display = "block";
      settingsPanel.style.display = "block";
      toggleBtn.textContent = "▲ 收起设置";
      initPopup();

      // Fetch groups
      try {
        const url = new URL(tab.url);
        fetchGroups(url.origin);
      } catch (e) {
        console.error(e);
      }
    } else {
      // 2. Not FlatNas Page
      if (hasConfig) {
        // Has Config -> Show Bookmark Mode (Settings Collapsed)
        appContentEl.style.display = "block";
        settingsPanel.style.display = "none";
        toggleBtn.textContent = "▼ 展开设置";
        initPopup();
      } else {
        // No Config -> Show Error/Guide
        errorMsgEl.style.display = "block";
        bindForceBtn();
      }
    }
  } catch (err) {
    console.error("Handshake fatal error:", err);
    checkingEl.style.display = "none";

    // Fallback: Try to show UI based on config even if handshake failed
    chrome.storage.sync.get(["nasDomains"], (result) => {
      const configStr = result.nasDomains || "";
      if (configStr.trim().length > 0) {
        appContentEl.style.display = "block";
        settingsPanel.style.display = "none";
        toggleBtn.textContent = "▼ 展开设置";
        initPopup();
      } else {
        errorMsgEl.style.display = "block";
        bindForceBtn();
      }
    });
  }
}

function initPopup() {
  chrome.storage.sync.get(["nasDomains"], (result) => {
    if (result.nasDomains) {
      document.getElementById("domainInput").value = result.nasDomains;

      // Try to fetch groups from first domain if we are not on FlatNas page (already handled in checkHandshake)
      // Actually doing it again doesn't hurt, or we can check if select is empty?
      // Just fetch it.
      const domains = result.nasDomains
        .split(",")
        .map((d) => d.trim())
        .filter((d) => d);
      if (domains.length > 0) {
        fetchGroups(domains[0]);
      }
    }
  });

  // Load from local storage immediately
  chrome.storage.local.get(["flatnasGroups"], (res) => {
    if (res.flatnasGroups) {
      updateGroupSelect(res.flatnasGroups);
    }
  });

  // 避免重复绑定
  const saveBtn = document.getElementById("saveBtn");
  const newSaveBtn = saveBtn.cloneNode(true);
  saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);

  newSaveBtn.addEventListener("click", () => {
    const input = document.getElementById("domainInput").value;
    const btn = document.getElementById("saveBtn");

    // 1. UI 交互反馈
    btn.textContent = "保存中...";
    btn.disabled = true;

    const domains = input
      .split(",")
      .map((d) => d.trim())
      .filter((d) => d.length > 0)
      .map((d) => {
        // 尝试提取 hostname (自动去除 http/https 和 端口号)
        try {
          const urlStr = d.startsWith("http") ? d : "http://" + d;
          return new URL(urlStr).hostname;
        } catch {
          // 降级处理
          return d
            .replace(/^https?:\/\//, "")
            .replace(/\/$/, "")
            .replace(/:\d+$/, "");
        }
      });

    chrome.storage.sync.set({ nasDomains: input }, () => {
      // 存储完成后更新规则
      updateRules(
        domains,
        () => {
          // 2. 成功：恢复按钮状态并提示
          btn.textContent = "通信中";
          btn.style.backgroundColor = "#4CAF50"; // 保持绿色
          btn.disabled = false;

          showStatus("设置已生效，请刷新 NAS 页面。");
        },
        (errorMsg) => {
          // 3. 失败：显示错误并恢复按钮
          console.error(errorMsg);
          btn.textContent = "通信失败";
          btn.style.backgroundColor = "#d32f2f"; // 红色
          btn.disabled = false;
          showStatus("保存失败: " + errorMsg);

          // 2秒后恢复为原始文字
          setTimeout(() => {
            btn.textContent = "保存并生效";
            btn.style.backgroundColor = "#4CAF50";
          }, 2000);
        },
      );
    });
  });
  // 避免重复绑定 (addBookmarkBtn)
  const addBtn = document.getElementById("addBookmarkBtn");
  if (addBtn) {
    const newAddBtn = addBtn.cloneNode(true);
    addBtn.parentNode.replaceChild(newAddBtn, addBtn);
    newAddBtn.addEventListener("click", handleAddBookmark);
  }
}

async function handleAddBookmark() {
  const btn = document.getElementById("addBookmarkBtn");
  const originalText = "添加当前页到收藏";
  btn.textContent = "添加中...";
  btn.disabled = true;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) throw new Error("无法获取当前标签页");

    const bookmark = {
      title: tab.title,
      url: tab.url,
      icon: tab.favIconUrl,
      categoryTitle: document.getElementById("groupSelect").value,
    };

    // Get domains
    chrome.storage.sync.get(["nasDomains"], async (result) => {
      try {
        let domains = (result.nasDomains || "")
          .split(",")
          .map((d) => d.trim())
          .filter((d) => d);

        if (domains.length === 0) throw new Error("请先设置 FlatNas 地址");

        // Try first domain
        let domain = domains[0];
        if (!domain.startsWith("http")) {
          domain = "http://" + domain;
        }
        // Remove trailing slash and port correction if needed
        domain = domain.replace(/\/$/, "");

        const res = await fetch(`${domain}/api/add-bookmark`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(bookmark),
        });

        if (!res.ok) {
          let errMsg = res.status;
          try {
            const errData = await res.json();
            if (errData.error) errMsg += " (" + errData.error + ")";
          } catch {
            // ignore JSON parse error, use status text if available
            if (res.statusText) errMsg += " " + res.statusText;
          }
          throw new Error("Server error: " + errMsg);
        }

        btn.textContent = "已添加";
        btn.style.backgroundColor = "#4CAF50";
        showStatus("添加成功！");

        setTimeout(() => {
          btn.textContent = originalText;
          btn.style.backgroundColor = "#ff9800";
          btn.disabled = false;
        }, 2000);
      } catch (err) {
        console.error(err);
        btn.textContent = "失败";
        btn.style.backgroundColor = "#d32f2f";
        showStatus("添加失败: " + err.message);

        setTimeout(() => {
          btn.textContent = originalText;
          btn.style.backgroundColor = "#ff9800";
          btn.disabled = false;
        }, 2000);
      }
    });
  } catch (err) {
    console.error(err);
    btn.textContent = "失败";
    btn.style.backgroundColor = "#d32f2f";
    showStatus("添加失败: " + err.message);

    setTimeout(() => {
      btn.textContent = originalText;
      btn.style.backgroundColor = "#ff9800";
      btn.disabled = false;
    }, 2000);
  }
}

function updateRules(domains, onSuccess, onError) {
  if (domains.length === 0) {
    chrome.declarativeNetRequest.updateDynamicRules(
      {
        removeRuleIds: [1],
        addRules: [],
      },
      () => {
        if (chrome.runtime.lastError) {
          if (onError) onError(chrome.runtime.lastError.message);
        } else {
          if (onSuccess) onSuccess();
        }
      },
    );
    return;
  }

  const newRule = {
    id: 1,
    priority: 1,
    action: {
      type: "modifyHeaders",
      responseHeaders: [
        { header: "content-security-policy", operation: "remove" },
        { header: "x-frame-options", operation: "remove" },
      ],
    },
    condition: {
      resourceTypes: ["sub_frame"],
      initiatorDomains: domains,
    },
  };

  chrome.declarativeNetRequest.updateDynamicRules(
    {
      removeRuleIds: [1],
      addRules: [newRule],
    },
    () => {
      if (chrome.runtime.lastError) {
        if (onError) onError(chrome.runtime.lastError.message);
      } else {
        if (onSuccess) onSuccess();
      }
    },
  );
}

function showStatus(msg) {
  const status = document.getElementById("status");
  status.textContent = msg;
  status.style.display = "block";
  setTimeout(() => {
    status.style.display = "none";
  }, 2000);
}

async function fetchGroups(domain) {
  if (!domain) return;
  if (!domain.startsWith("http")) {
    domain = "http://" + domain;
  }
  domain = domain.replace(/\/$/, "");

  try {
    const res = await fetch(`${domain}/api/data`);
    if (!res.ok) return;
    const data = await res.json();
    // Top-level groups
    const groupsData = data.groups;
    if (groupsData && Array.isArray(groupsData)) {
      const groups = groupsData.map((g) => ({ title: g.title, id: g.id }));
      chrome.storage.local.set({ flatnasGroups: groups });
      updateGroupSelect(groups);
    }
  } catch (e) {
    console.error("Failed to fetch groups", e);
  }
}

function updateGroupSelect(groups) {
  const select = document.getElementById("groupSelect");
  if (!select) return;

  // Save current selection
  const currentVal = select.value;

  if (groups && groups.length > 0) {
    select.innerHTML = '<option value="">选择分组 (默认收集箱)</option>';
    groups.forEach((g) => {
      const option = document.createElement("option");
      option.value = g.title;
      option.textContent = g.title;
      select.appendChild(option);
    });

    if (currentVal) {
      // Restore selection if still exists
      const exists = groups.find((g) => g.title === currentVal);
      if (exists) select.value = currentVal;
    }

    select.style.display = "block";
  } else {
    select.style.display = "none";
  }
}
