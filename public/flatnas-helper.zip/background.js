chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "sendToTransfer",
      title: "发送到文件传输助手",
      contexts: ["selection", "image"],
    });
    chrome.contextMenus.create({
      id: "sendToMemo",
      title: "发送到备忘录",
      contexts: ["selection"],
    });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "sendToTransfer" || info.menuItemId === "sendToMemo") {
    let content = info.selectionText;
    let type = "text";

    if (info.mediaType === "image" && info.srcUrl) {
      try {
        const response = await fetch(info.srcUrl);
        const blob = await response.blob();
        content = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        });
        type = "image";
      } catch (e) {
        console.error("Failed to fetch image", e);
        content = info.srcUrl;
      }
    } else if (!content) {
      content = info.srcUrl;
    }

    if (!content) return;
    await handleSendText(content, info.menuItemId, tab, type);
  }
});

async function handleSendText(content, target, sourceTab, type = "text") {
  const storage = await chrome.storage.sync.get(["nasDomains"]);
  const nasDomainsStr = storage.nasDomains || "";

  if (!nasDomainsStr.trim()) {
    console.warn("No NAS domains configured.");
    return;
  }

  const { hostnames, origins, urlPatterns } = parseNasDomains(nasDomainsStr);

  const targetTab = await findOrOpenFlatNasTab({ hostnames, origins, urlPatterns });

  if (targetTab) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: targetTab.id, allFrames: true },
        func: injectText,
        args: [content, target, type],
      });
    } catch (e) {
      console.error("Failed to execute script:", e);
    }
  } else {
    console.warn("No FlatNas tab found.");
  }
}

function parseNasDomains(nasDomainsStr) {
  const rawEntries = nasDomainsStr
    .split(/[\n,]/)
    .map((d) => d.trim())
    .filter((d) => d);

  const hostnames = [];
  const origins = [];

  for (const entry of rawEntries) {
    const urlStr =
      entry.startsWith("http://") || entry.startsWith("https://") ? entry : `http://${entry}`;

    try {
      const url = new URL(urlStr);
      if (url.hostname) hostnames.push(url.hostname);
      if (url.origin) origins.push(url.origin);
    } catch {
      const hostname = entry
        .replace(/^https?:\/\//, "")
        .replace(/\/.*$/, "")
        .replace(/#.*$/, "")
        .replace(/\?.*$/, "")
        .trim();
      if (hostname) hostnames.push(hostname);
    }
  }

  const uniq = (arr) => Array.from(new Set(arr.filter(Boolean)));
  const uniqHostnames = uniq(hostnames);
  const uniqOrigins = uniq(origins);

  const urlPatterns = [
    ...uniqHostnames.map((h) => `*://${h}/*`),
    ...uniqOrigins.map((o) => `${o}/*`),
  ];

  return {
    hostnames: uniqHostnames,
    origins: uniqOrigins,
    urlPatterns: uniq(urlPatterns),
  };
}

function tabMatches(tabUrl, { hostnames, origins }) {
  if (!tabUrl) return false;
  for (const origin of origins) {
    if (tabUrl.startsWith(origin)) return true;
  }
  for (const hostname of hostnames) {
    if (tabUrl.includes(hostname)) return true;
  }
  return false;
}

function waitForTabComplete(tabId, timeoutMs = 12000) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(false);
    }, timeoutMs);

    const listener = (updatedTabId, changeInfo) => {
      if (updatedTabId !== tabId) return;
      if (changeInfo.status === "complete") {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(true);
      }
    };

    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function findOrOpenFlatNasTab({ hostnames, origins, urlPatterns }) {
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (activeTab?.url && tabMatches(activeTab.url, { hostnames, origins })) return activeTab;

  if (urlPatterns.length > 0) {
    const matchedTabs = await chrome.tabs.query({ url: urlPatterns });
    const firstMatched = matchedTabs.find(
      (t) => t?.id && t?.url && tabMatches(t.url, { hostnames, origins }),
    );
    if (firstMatched) return firstMatched;
  }

  const urlToOpen = origins[0] || (hostnames[0] ? `http://${hostnames[0]}` : null);
  if (!urlToOpen) return null;

  const createdTab = await chrome.tabs.create({ url: urlToOpen, active: true });
  if (!createdTab?.id) return createdTab;

  await waitForTabComplete(createdTab.id);
  const refreshedTab = await chrome.tabs.get(createdTab.id);
  return refreshedTab || createdTab;
}

async function injectText(text, target, type = "text") {
  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function normalizeText(s) {
    return (s || "").replace(/\s+/g, " ").trim();
  }

  function showToast(message, type = "error") {
    // Only show toast in the top frame to avoid spamming if multiple frames match
    if (window.top !== window && type !== "ok") {
      // If we are in an iframe and fail, we might want to stay silent unless we are sure this was the intended target
      // But for debugging, we'll log to console
      console.log("FlatNas helper (iframe): " + message);
      return;
    }

    const div = document.createElement("div");
    div.textContent = message;
    const bg = type === "ok" ? "rgba(0,160,90,0.85)" : "rgba(255,0,0,0.85)";
    div.style.cssText = `position:fixed; top:20px; right:20px; background:${bg}; color:white; padding:10px 14px; z-index:99999; border-radius:10px; font-size:13px; pointer-events:none; max-width:60vw; white-space:pre-wrap; box-shadow: 0 4px 6px rgba(0,0,0,0.1);`;
    document.body.appendChild(div);
    setTimeout(() => div.remove(), 4000);
  }

  // Spoof visibility to trick the page into rendering if it's in the background
  try {
    Object.defineProperty(document, "visibilityState", {
      get: () => "visible",
      configurable: true,
    });
    Object.defineProperty(document, "hidden", { get: () => false, configurable: true });
    document.dispatchEvent(new Event("visibilitychange"));
    window.dispatchEvent(new Event("focus"));
  } catch {
    // Ignore errors if property is not configurable
  }

  async function ensureTransferChatMode(card) {
    const btns = Array.from(card.querySelectorAll("button"));
    const chatBtn = btns.find((b) => normalizeText(b.textContent) === "聊天");
    if (!chatBtn) return false;

    const isActive = chatBtn.classList.contains("bg-white/20");
    if (!isActive) {
      // Dispatch full click sequence
      chatBtn.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
      chatBtn.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
      chatBtn.click();

      await delay(500); // Increased delay for background rendering
      return true; // Switched mode
    }
    return false; // Already in chat mode
  }

  function findTransferAssistantCard() {
    // Strategy 1: Find by text "文件传输助手" and traverse up
    const candidates = Array.from(document.querySelectorAll("div,span,h1,h2,h3,p")).filter((el) => {
      const t = (el.textContent || "").trim();
      return t === "文件传输助手" || t.includes("文件传输助手");
    });

    for (const el of candidates) {
      let cursor = el;
      for (let i = 0; i < 15 && cursor; i++) {
        if (cursor.querySelector) {
          // Check for input
          const hasInput = !!cursor.querySelector('textarea[placeholder*="Shift+Enter"]');
          // Check for send button (relaxed check)
          const hasSendBtn = Array.from(cursor.querySelectorAll("button")).some((b) =>
            (b.textContent || "").includes("发送"),
          );

          // Also check for tab buttons to be sure it's the right card
          const hasTabs = Array.from(cursor.querySelectorAll("button")).some(
            (b) => (b.textContent || "").includes("聊天") || (b.textContent || "").includes("文件"),
          );

          if ((hasInput || hasTabs) && (hasSendBtn || hasTabs)) return cursor;
        }
        cursor = cursor.parentElement;
      }
    }

    return null;
  }

  // Retry logic wrapper
  async function attemptFindAndFill(maxRetries = 5) {
    let input = null;
    let submitBtn = null;
    let errorReason = "";

    for (let attempt = 0; attempt < maxRetries; attempt++) {
      if (attempt > 0) await delay(500); // Wait before retry

      input = null;
      submitBtn = null;
      errorReason = "";

      if (target === "sendToTransfer") {
        const card = findTransferAssistantCard();
        if (card) {
          await ensureTransferChatMode(card);
          // Re-query after potential mode switch
          input = card.querySelector('textarea[placeholder*="Shift+Enter"]');
          const btns = Array.from(card.querySelectorAll("button"));
          submitBtn =
            btns.find((b) => (b.textContent || "").includes("发送") && !b.disabled) || null;

          if (!input) errorReason = "找到了卡片，但没找到输入框(Shift+Enter)";
          else if (!submitBtn) errorReason = "找到了卡片和输入框，但没找到发送按钮";
        } else {
          errorReason = "未找到'文件传输助手'卡片";
        }

        // Fallback: Global search if card logic failed
        if (!input) {
          const textareas = document.querySelectorAll("textarea");
          for (const ta of textareas) {
            if (ta.placeholder && ta.placeholder.includes("Shift+Enter")) {
              input = ta;
              break;
            }
          }
          if (input) errorReason = "通过全局搜索找到了输入框，但之前卡片匹配失败";
        }

        // Fallback: Find submit button near input
        if (!submitBtn && input) {
          let cursor = input.parentElement;
          for (let i = 0; i < 12 && cursor; i++) {
            const btns = Array.from(cursor.querySelectorAll("button"));
            const found = btns.find((b) => (b.textContent || "").includes("发送") && !b.disabled);
            if (found) {
              submitBtn = found;
              break;
            }
            cursor = cursor.parentElement;
          }
        }
      } else if (target === "sendToMemo") {
        const textareas = document.querySelectorAll("textarea");
        for (const ta of textareas) {
          if (ta.placeholder && ta.placeholder.includes("写点什么")) {
            input = ta;
            break;
          }
        }
        if (!input) errorReason = "未找到备忘录输入框(写点什么)";
      }

      if (input) {
        // Success found
        break;
      }
    }

    return { input, submitBtn, errorReason };
  }

  const { input, submitBtn, errorReason } = await attemptFindAndFill();

  if (input) {
    input.focus();

    if (type === "image") {
      try {
        const [header, base64Data] = text.split(",");
        const mimeMatch = header.match(/:(.*?);/);
        const mimeType = mimeMatch ? mimeMatch[1] : "image/png";

        const byteCharacters = atob(base64Data);
        const byteArrays = [];
        for (let offset = 0; offset < byteCharacters.length; offset += 512) {
          const slice = byteCharacters.slice(offset, offset + 512);
          const byteNumbers = new Array(slice.length);
          for (let i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
          }
          const byteArray = new Uint8Array(byteNumbers);
          byteArrays.push(byteArray);
        }
        const blob = new Blob(byteArrays, { type: mimeType });
        const file = new File([blob], "image." + mimeType.split("/")[1], { type: mimeType });

        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);

        const pasteEvent = new ClipboardEvent("paste", {
          bubbles: true,
          cancelable: true,
          clipboardData: dataTransfer,
        });
        input.dispatchEvent(pasteEvent);

        await delay(800);
      } catch (e) {
        console.error("Image paste failed", e);
        showToast("图片粘贴失败: " + e.message);
        return;
      }
    } else {
      const originalValue = input.value;

      let nextValue = text;
      if (target === "sendToMemo" && originalValue) {
        const sep = originalValue.endsWith("\n") ? "" : "\n";
        nextValue = originalValue + sep + text;
      }

      const valueSetter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype,
        "value",
      )?.set;
      if (valueSetter) {
        valueSetter.call(input, nextValue);
      } else {
        input.value = nextValue;
      }

      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));

      // Simulate keyboard typing (optional, for some frameworks)
      input.dispatchEvent(new KeyboardEvent("keydown", { key: "Process", bubbles: true }));
      input.dispatchEvent(new KeyboardEvent("keyup", { key: "Process", bubbles: true }));
    }

    if (target === "sendToTransfer") {
      await delay(100);

      // Method 1: Try Enter key first (since placeholder says Shift+Enter to newline)
      // We simulate a plain Enter key press to submit
      try {
        const enterEvent = new KeyboardEvent("keydown", {
          bubbles: true,
          cancelable: true,
          key: "Enter",
          code: "Enter",
          keyCode: 13,
          which: 13,
          shiftKey: false,
        });
        input.dispatchEvent(enterEvent);

        // Some frameworks need keyup too
        input.dispatchEvent(
          new KeyboardEvent("keyup", {
            bubbles: true,
            cancelable: true,
            key: "Enter",
            code: "Enter",
            keyCode: 13,
            which: 13,
            shiftKey: false,
          }),
        );
      } catch (e) {
        console.error("Enter key simulation failed", e);
      }

      await delay(100);

      // Method 2: Click the button if it exists
      const canClickSend = !!submitBtn && !submitBtn.disabled;
      if (canClickSend) {
        try {
          submitBtn.dispatchEvent(
            new MouseEvent("click", { bubbles: true, cancelable: true, view: window }),
          );
        } catch {
          // ignore
        }
        submitBtn.click();
        showToast("已发送", "ok");
      } else {
        // If we simulated Enter, we might not need the button, but we warn if button wasn't found just in case
        if (!submitBtn) {
          showToast("已尝试回车发送 (未找到发送按钮)", "ok");
        } else {
          showToast("已尝试回车发送 (按钮不可用)", "ok");
        }
      }
    } else {
      showToast("已添加到备忘录", "ok");
    }

    const originalBorder = input.style.borderColor;
    input.style.borderColor = "#4caf50";
    input.style.borderWidth = "2px";
    setTimeout(() => {
      input.style.borderColor = originalBorder;
      input.style.borderWidth = "";
    }, 1000);
  } else {
    showToast("FlatNas助手发送失败: " + errorReason);
  }
}
